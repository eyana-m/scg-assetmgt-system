<?php

$config['upload_path'] = './uploads/';
$config['allowed_types'] = 'gif|jpg|png|jpeg|csv';
$config['max_size']	= '0';
$config['max_width']  = '0';
$config['max_height']  = '0';
$config['encrypt_name'] = TRUE;
$config['overwrite'] = FALSE;