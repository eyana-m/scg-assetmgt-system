<?php echo $page->pag_content; ?>

Hello bish