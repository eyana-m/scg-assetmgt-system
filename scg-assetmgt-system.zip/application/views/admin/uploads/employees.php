<h4>Import multiple employees in csv format</h4>
<form  method="post" id="import" enctype="multipart/form-data">
	<input type="file" id="import_batch" name="import_batch" value="" />
	<input class ="btn btn-small btn-danger no-border-radius" type="submit" name="import" value="Import" style="font-size:12px">
</form>