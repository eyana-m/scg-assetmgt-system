
<h4>Import multiple assets in csv format</h4>
<form  method="post" id="import" enctype="multipart/form-data">
	
	
	
	<table class="table-form table-bordered">
		<tr>
			<th>Choose File</th>
			<td><input style="font-size:11px" type="file" id="import_batch" name="import_batch" value="" /></td>
		</tr>
		<tr>
			<td></td>
			<td><input class ="btn btn-small btn-primary no-border-radius" type="submit" name="import" value="Import" style="font-size:12px"></td>
		</tr>
	</table>

</form>