<p class="center">You're not allowed to access that page.</p>
<br />
<div class="center">
	<input type="button" value="Go Back" class="btn large primary" onclick="redirect_back();" />
</div>