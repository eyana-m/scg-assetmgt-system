
<div class="col-md-12">
<h4>
Filtered Results: <small><?php echo template('content-top'); ?>
</small>
</h4>
</div>







<?php echo template('content'); ?>