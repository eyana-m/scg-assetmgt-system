<div class="page-nav">
	<ul class="nav nav-pills pull-right">
		<li><a href="<?php echo site_url('admin/employees/create'); ?>">Create Employee</a></li>
	</ul>
</div>