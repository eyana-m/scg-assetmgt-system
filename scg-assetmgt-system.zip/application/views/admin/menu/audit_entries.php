<div class="page-nav">
	<ul class="nav nav-pills pull-right">
		<li><a href="<?php echo site_url('admin/audit_entries/create'); ?>">Create Audit Entry</a></li>
	</ul>
</div>