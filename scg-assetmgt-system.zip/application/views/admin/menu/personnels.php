<div class="page-nav">
	<ul class="nav nav-pills pull-right">
		<li><a href="<?php echo site_url('admin/personnels/create'); ?>">Create Personnel</a></li>
	</ul>
</div>