<div class="page-nav">
	<ul class="nav nav-pills pull-right">
		<li><a href="<?php echo site_url('admin/hardwares/create'); ?>">Create Hardware</a></li>
	</ul>
</div>