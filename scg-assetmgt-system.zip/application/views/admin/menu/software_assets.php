<div class="page-nav">
	<ul class="nav nav-pills pull-right">
		<li><a href="<?php echo site_url('admin/software_assets/create'); ?>">Create Software Asset</a></li>
	</ul>
</div>